package logtest

// Message is what a log message promises: the levels it may be logged at and
// the fields it always carries, besides the common ones (time, level, msg,
// service, version, and request_id within a request).
type Message struct {
	Levels []string
	Keys   []string
}

// Contract is the service's log schema: every message the code can emit, with
// its promises. It is the one place that says what each message is for, and
// tests hold the rest to it:
//
//   - the log contract test (cmd/api) runs the service and checks every line
//     it writes against this table;
//   - the schema tests (internal/logx) check that every message in the code is
//     listed here, that nothing listed here is stale, that every field named
//     here is a declared Key, and that the Messages table in docs/logging.md says the
//     same thing.
//
// Adding a log line therefore means adding it here, and to that table.
//
// "request received" and "response sent" have more precise level rules than a
// set of levels can say; the contract test checks those directly: both are
// DEBUG for the healthcheck, and "response sent" is ERROR for a 5xx.
var Contract = map[string]Message{
	// Lifecycle: logged outside any request, so no request_id.
	"using upstream": {[]string{"INFO"}, []string{"url", "timeout", "retries"}},
	"using the in-memory store: for development only; items are lost when the service stops": {[]string{"WARN"}, nil},
	// feature:flags
	"using feature flags": {[]string{"INFO"}, []string{"url", "timeout", "cache_ttl"}},
	// end feature:flags
	// feature:tracing
	"using tracing":  {[]string{"INFO"}, []string{"url"}},
	"tracing failed": {[]string{"WARN"}, []string{"error"}},
	// end feature:tracing
	"using header guard": {[]string{"INFO"}, []string{"mode", "max_headers", "max_header_bytes", "max_total_bytes"}},
	"using API keys":     {[]string{"INFO"}, []string{"api_keys", "reads"}},
	"using limits":       {[]string{"INFO"}, []string{"max_in_flight", "rate_limit", "rate_burst"}},
	"authentication is off: every request is allowed": {[]string{"WARN"}, nil},
	// feature:flags
	"feature flags: no FLAGS_URL, using default values only": {[]string{"INFO"}, nil},
	// end feature:flags
	"server started": {[]string{"INFO"}, []string{"addr"}},
	"shutting down":  {[]string{"INFO"}, []string{"timeout"}},
	"shutdown timed out; stopping requests in flight": {[]string{"WARN"}, []string{"in_flight"}},
	"server stopped":           {[]string{"INFO"}, nil},
	"not ready":                {[]string{"WARN"}, []string{"reason"}},
	"ready again":              {[]string{"INFO"}, nil},
	"profiling server started": {[]string{"INFO"}, []string{"addr"}},
	"profiling server failed":  {[]string{"ERROR"}, []string{"error"}},
	"profiling server is reachable beyond this machine; keep its port private": {[]string{"WARN"}, []string{"addr"}},
	"using runtime":            {[]string{"INFO"}, []string{"go_version", "gomaxprocs", "memory_limit_bytes", "memory_limit_source", "stats_interval"}},
	"panic in background task": {[]string{"ERROR"}, []string{"task", "panic", "stack"}},
	"runtime stats":            {[]string{"INFO"}, []string{"heap_bytes", "runtime_memory_bytes", "goroutines", "gc_cycles"}},
	"service failed":           {[]string{"ERROR"}, []string{"error"}},

	// The four ends of a request, in order.
	"request received":           {[]string{"INFO", "DEBUG"}, []string{"method", "path", "content_length"}},
	"upstream request sent":      {[]string{"INFO"}, []string{"upstream"}},
	"upstream response received": {[]string{"INFO"}, []string{"upstream", "upstream_status", "upstream_duration_ms"}},
	"response sent":              {[]string{"INFO", "DEBUG", "ERROR"}, []string{"method", "route", "path", "status", "bytes", "duration_ms"}},

	// What can go wrong in between.
	"internal error":              {[]string{"ERROR"}, []string{"method", "route", "path", "error"}},
	"client disconnected":         {[]string{"INFO"}, []string{"method", "route", "path", "error"}},
	"request stopped by shutdown": {[]string{"WARN"}, []string{"method", "route", "path", "error"}},
	"panic serving request":       {[]string{"ERROR"}, []string{"method", "route", "path", "panic", "stack"}},
	"upstream request failed":     {[]string{"WARN"}, []string{"upstream", "upstream_duration_ms", "error"}},
	"upstream request cancelled":  {[]string{"DEBUG"}, []string{"upstream", "upstream_duration_ms", "error"}},
	"upstream request retried":    {[]string{"INFO"}, []string{"upstream", "upstream_duration_ms", "attempt", "error"}},
	// A request the server answered itself, before the handler: no
	// request_id, method or path, since it never got that far.
	"request rejected by the server": {[]string{"WARN"}, []string{"duration_ms"}},

	// Header screening (internal/headerguard).
	"request headers rejected":          {[]string{"INFO"}, []string{"reason", "status"}},
	"request headers would be rejected": {[]string{"INFO"}, []string{"reason", "status"}},
	"request headers stripped":          {[]string{"DEBUG"}, []string{"headers"}},

	// Authentication (internal/apikey).
	"request refused by authentication": {[]string{"INFO"}, []string{"reason", "status"}},
	"API keys reloaded":                 {[]string{"INFO"}, []string{"api_keys"}},
	"API keys not reloaded":             {[]string{"ERROR"}, []string{"error"}},

	// feature:validation
	// Request validation (internal/validator).
	"using request validation": {[]string{"INFO"}, []string{"url", "timeout", "fail_open"}},
	"request validation is off: no VALIDATOR_URL; every request goes unchecked": {[]string{"WARN"}, nil},
	"request refused by validation":                                             {[]string{"INFO"}, []string{"reason"}},
	"request would be refused by validation":                                    {[]string{"INFO"}, []string{"reason"}},
	"request validation unavailable":                                            {[]string{"WARN"}, []string{"enforcing", "fail_open", "error"}},
	"request validation recovered":                                              {[]string{"INFO"}, []string{"failures", "duration_ms"}},
	// end feature:validation

	// Feature flags.
	// feature:flags
	"flag service unavailable, using default flag values": {[]string{"WARN"}, []string{"flag", "error"}},
	"flag service recovered":                              {[]string{"INFO"}, []string{"fallbacks", "duration_ms"}},
	"flag evaluation failed, using default":               {[]string{"WARN", "DEBUG"}, []string{"flag", "default", "error"}},
	"flag has no configured default, using false":         {[]string{"ERROR"}, []string{"flag"}},
	// end feature:flags
}

// OutsideRequests lists the messages that are logged outside any request, and
// so legitimately have no request_id. Every other message has one.
var OutsideRequests = []string{
	"using upstream", "using the in-memory store: for development only; items are lost when the service stops", "using header guard", "using API keys", "using limits", "API keys reloaded", "API keys not reloaded",
	"authentication is off: every request is allowed",
	// feature:flags
	"using feature flags", "feature flags: no FLAGS_URL, using default values only",
	// end feature:flags
	// feature:tracing
	"using tracing", "tracing failed",
	// end feature:tracing
	"server started", "shutting down", "server stopped", "not ready", "ready again", "profiling server started", "profiling server failed",
	"profiling server is reachable beyond this machine; keep its port private",
	"using runtime", "runtime stats", "service failed", "panic in background task",
	"request rejected by the server", "shutdown timed out; stopping requests in flight",
	// feature:validation
	"using request validation", "request validation is off: no VALIDATOR_URL; every request goes unchecked",
	// end feature:validation
}
