package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// ciRun is a workflow run as the GitHub API gives it, cut to what a record
// reads.
const ciRun = `{
  "id": 42, "head_sha": "abc1234def", "run_attempt": 1, "conclusion": "success",
  "run_started_at": "2026-10-05T10:00:00Z",
  "head_commit": {"message": "Merge pull request #9\n\nAdd things"}
}`

// ciJobs is the run's jobs, one object each, as gh api --paginate --jq
// '.jobs[]' prints them: test waits 3s for a runner and runs 60s; lint starts
// later and finishes last; a skipped job, and a skipped step, are left out.
const ciJobs = `{"name": "test", "conclusion": "success", "created_at": "2026-10-05T10:00:01Z", "started_at": "2026-10-05T10:00:04Z", "completed_at": "2026-10-05T10:01:04Z",
 "steps": [{"name": "Set up job", "conclusion": "success", "started_at": "2026-10-05T10:00:04Z", "completed_at": "2026-10-05T10:00:06Z"},
           {"name": "Unit tests", "conclusion": "success", "started_at": "2026-10-05T10:00:06Z", "completed_at": "2026-10-05T10:01:00Z"},
           {"name": "Upload", "conclusion": "skipped", "started_at": "2026-10-05T10:01:00Z", "completed_at": "2026-10-05T10:01:00Z"},
           {"name": "Post", "conclusion": "success", "started_at": "2026-10-05T10:01:01Z", "completed_at": "2026-10-05T10:01:00Z"}]}
{"name": "lint", "conclusion": "success", "created_at": "2026-10-05T10:00:01Z", "started_at": "2026-10-05T10:00:10Z", "completed_at": "2026-10-05T10:02:10Z", "steps": []}
{"name": "deploy", "conclusion": "skipped", "created_at": "2026-10-05T10:00:01Z", "started_at": "2026-10-05T10:00:01Z", "completed_at": "2026-10-05T10:00:01Z", "steps": []}
`

// lastLine is the last job in jobs: the skipped one.
func lastLine(jobs string) string {
	lines := strings.Split(strings.TrimSpace(jobs), "\n")
	return lines[len(lines)-1]
}

func writeFile(t *testing.T, name, content string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), name)
	if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func ciRecord1(t *testing.T, run, jobs string) (ciRecord, error) {
	t.Helper()
	var out strings.Builder
	err := runCIRecord([]string{"-run", writeFile(t, "run.json", run), "-jobs", writeFile(t, "jobs.json", jobs)}, &out)
	if err != nil {
		return ciRecord{}, err
	}
	var r ciRecord
	if err := json.Unmarshal([]byte(out.String()), &r); err != nil {
		t.Fatalf("record isn't JSON: %v\n%s", err, out.String())
	}
	return r, nil
}

func TestCIRecord(t *testing.T) {
	r, err := ciRecord1(t, ciRun, ciJobs)
	if err != nil {
		t.Fatal(err)
	}
	if r.SHA != "abc1234def" || r.Subject != "Merge pull request #9" || r.RunID != 42 || r.Attempt != 1 || r.Time != "2026-10-05T10:00:00Z" {
		t.Errorf("identity = %+v", r)
	}
	if r.WallSeconds == nil || *r.WallSeconds != 130 {
		t.Errorf("wall = %v, want 130s: from the run's start to lint, the last job, finishing", r.WallSeconds)
	}
	if len(r.Jobs) != 2 || r.Jobs[0].Name != "lint" || r.Jobs[1].Name != "test" {
		t.Fatalf("jobs = %+v, want lint and test, by name, without the skipped one", r.Jobs)
	}
	test := r.Jobs[1]
	if test.QueuedSeconds != 3 || test.Seconds != 60 {
		t.Errorf("test queued %vs and ran %vs, want 3 and 60", test.QueuedSeconds, test.Seconds)
	}
	var steps []string
	for _, s := range test.Steps {
		steps = append(steps, s.Name)
	}
	if strings.Join(steps, ", ") != "Set up job, Unit tests, Post" || test.Steps[1].Seconds != 54 {
		t.Errorf("steps = %+v, want three, without the skipped one, Unit tests 54s", test.Steps)
	}
	if test.Steps[2].Seconds != 0 {
		t.Errorf("a step ending a second before it started (GitHub's rounding) = %vs, want 0", test.Steps[2].Seconds)
	}
}

// TestCIRecordOfARerun checks a re-run of failed jobs: its jobs keep their
// times, those carried over from the first attempt included, but it has no
// pipeline time, and a carried-over job's wait isn't counted. GitHub gives a
// carried-over job the new attempt's created_at and its own, earlier,
// started_at, as below for test.
func TestCIRecordOfARerun(t *testing.T) {
	run := strings.Replace(ciRun, `"run_attempt": 1`, `"run_attempt": 2`, 1)
	run = strings.Replace(run, `"run_started_at": "2026-10-05T10:00:00Z"`, `"run_started_at": "2026-10-05T10:00:05Z"`, 1)
	r, err := ciRecord1(t, run, ciJobs)
	if err != nil {
		t.Fatal(err)
	}
	if r.WallSeconds != nil {
		t.Errorf("a re-run's wall = %v, want none", *r.WallSeconds)
	}
	lint, test := r.Jobs[0], r.Jobs[1]
	if test.Seconds != 60 || test.QueuedSeconds != 0 {
		t.Errorf("carried-over test: ran %vs, queued %vs; want 60 and 0", test.Seconds, test.QueuedSeconds)
	}
	if lint.Seconds != 120 || lint.QueuedSeconds != 9 {
		t.Errorf("re-run lint: ran %vs, queued %vs; want 120 and 9", lint.Seconds, lint.QueuedSeconds)
	}
}

func TestCIRecordRefuses(t *testing.T) {
	for name, tt := range map[string]struct{ run, jobs string }{
		"a failed run":          {strings.Replace(ciRun, `"success"`, `"failure"`, 1), ciJobs},
		"a cancelled run":       {strings.Replace(ciRun, `"success"`, `"cancelled"`, 1), ciJobs},
		"no jobs":               {ciRun, ""},
		"only skipped jobs":     {ciRun, lastLine(ciJobs)},
		"a bad timestamp":       {ciRun, strings.Replace(ciJobs, "2026-10-05T10:00:04Z", "soon", 1)},
		"a run that isn't JSON": {"{", ciJobs},
	} {
		t.Run(name, func(t *testing.T) {
			_, err := ciRecord1(t, tt.run, tt.jobs)
			if err == nil {
				t.Fatal("nil error, want a refusal")
			}
			t.Log(err)
		})
	}
	if err := runCIRecord([]string{"-run", "x.json"}, &strings.Builder{}); err == nil {
		t.Error("ci-record without -jobs = nil error, want one")
	}
}

func TestTrendsChartsCIRecords(t *testing.T) {
	a, err := ciRecord1(t, ciRun, ciJobs)
	if err != nil {
		t.Fatal(err)
	}
	b := a
	b.SHA, b.Subject, b.WallSeconds = "fff9999aaa", "<b>Next</b>", ptr(180)
	b.Jobs = []ciJob{{Name: "test", Seconds: 90}, {Name: "fuzz", Seconds: 150}} // lint gone, fuzz new
	dir := t.TempDir()
	for name, r := range map[string]ciRecord{"20261005T100000-abc1234.json": a, "20261005T110000-fff9999.json": b} {
		buf, _ := json.Marshal(r)
		if err := os.WriteFile(filepath.Join(dir, name), buf, 0o600); err != nil {
			t.Fatal(err)
		}
	}
	perf := record1(t, "aaa1111", "First", "2026-10-01T10:00:00Z")

	var out strings.Builder
	if err := runTrends([]string{"-records", writeRecords(t, perf), "-ci-records", dir}, &out); err != nil {
		t.Fatal(err)
	}
	page := out.String()
	mustContain(t, page, "CI pipeline time", "CI time per job",
		"abc1234 pipeline: 2.17 minutes", "fff9999 pipeline: 3.00 minutes", // 130s and 180s, oldest first
		"fff9999 fuzz: 2.50 minutes", "abc1234 lint: 2.00 minutes",
		"aaa1111 p99") // the performance charts keep their own commits
	if strings.Contains(page, "<b>Next</b>") {
		t.Error("a commit subject went into the page unescaped")
	}
	if strings.Contains(page, "fff9999 lint") || strings.Contains(page, "abc1234 fuzz") {
		t.Error("a job charted for a run it wasn't in")
	}

	if err := runTrends([]string{"-records", writeRecords(t, perf), "-ci-records", t.TempDir()}, &strings.Builder{}); err == nil {
		t.Error("trends with an empty -ci-records directory = nil error, want one")
	}
}

// TestTrendsFragment checks -fragment writes the charts alone, wrapped for
// the docs site's styles, with no blank line: Markdown would end the raw
// HTML block there, and pandoc would treat the rest as text.
func TestTrendsFragment(t *testing.T) {
	a, err := ciRecord1(t, ciRun, ciJobs)
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	buf, _ := json.Marshal(a)
	if err := os.WriteFile(filepath.Join(dir, "20261005T100000-abc1234.json"), buf, 0o600); err != nil {
		t.Fatal(err)
	}
	var out strings.Builder
	err = runTrends([]string{"-fragment", "-records", writeRecords(t, record1(t, "aaa1111", "First", "2026-10-01T10:00:00Z")), "-ci-records", dir}, &out)
	if err != nil {
		t.Fatal(err)
	}
	frag := out.String()
	if !strings.HasPrefix(frag, `<div class="perf-history">`) || !strings.HasSuffix(frag, "</div>\n") {
		t.Errorf("fragment isn't wrapped in <div class=\"perf-history\">:\n%.200s", frag)
	}
	// (Its <title> elements are the points' hover text, inside the SVG.)
	for _, page := range []string{"<!doctype", "<html", "<head", "<body", "<style"} {
		if strings.Contains(frag, page) {
			t.Errorf("fragment contains %s: it goes inside a docs page, which styles it", page)
		}
	}
	// Markdown keeps a run of lines as raw HTML only while each starts with
	// a tag: a blank line, or one starting with text, ends it, and pandoc
	// would wrap what follows in <p>, breaking the charts.
	for i, line := range strings.Split(strings.TrimSuffix(frag, "\n"), "\n") {
		if !strings.HasPrefix(line, "<") {
			t.Errorf("fragment line %d doesn't start with a tag: %.80q", i+1, line)
		}
	}
	mustContain(t, frag, "Latency under load", "CI pipeline time", "CI time per job")
}

// withValidator adds the API's validation-call histogram to a side's metric
// snapshots, as the change over each run: 50 calls at or under 2.5ms, 99 under
// 5ms, 100 under 10ms.
func withValidator(t *testing.T, dir, side string) {
	t.Helper()
	start := "validator_call_duration_seconds_count 0\nvalidator_call_duration_seconds_sum 0\n"
	end := "validator_call_duration_seconds_count 100\nvalidator_call_duration_seconds_sum 0.3\n" +
		`validator_call_duration_seconds_bucket{le="0.001"} 0` + "\n" +
		`validator_call_duration_seconds_bucket{le="0.0025"} 50` + "\n" +
		`validator_call_duration_seconds_bucket{le="0.005"} 99` + "\n" +
		`validator_call_duration_seconds_bucket{le="0.01"} 100` + "\n" +
		`validator_call_duration_seconds_bucket{le="+Inf"} 100` + "\n"
	for i := 1; i <= 2; i++ {
		stem := filepath.Join(dir, side+"-"+string(rune('0'+i)))
		for name, add := range map[string]string{".metrics-start.prom": start, ".metrics-end.prom": end} {
			f, err := os.OpenFile(stem+name, os.O_APPEND|os.O_WRONLY, 0)
			if err != nil {
				t.Fatal(err)
			}
			_, _ = f.WriteString(add)
			f.Close()
		}
	}
}

// TestReportValidator checks the PR report's request validation section:
// the calls' median and p99 from the histogram, calls per request, and a
// dash for a base that made none.
func TestReportValidator(t *testing.T) {
	dir := k6Dir(t, [3]float64{1, 2, 0}, [3]float64{1, 2, 0})
	withResources(t, dir, "base", 10, 15, 0.1, 2048*1000)
	withResources(t, dir, "head", 10, 15, 0.1, 2048*1000)
	withValidator(t, dir, "head")
	report, _ := render(t, options{baseName: "main", loadDir: dir})
	mustContain(t, report, "### Request validation",
		"| Median call | — | 2.50ms | |", "| p99 call | — | 5.00ms | |", "| Calls per request | — | 0.10 | |")

	withValidator(t, dir, "base")
	report, _ = render(t, options{baseName: "main", loadDir: dir})
	mustContain(t, report, "| Median call | 2.50ms | 2.50ms | +0.0% |")

	none := k6Dir(t, [3]float64{1, 2, 0}, [3]float64{1, 2, 0})
	withResources(t, none, "base", 10, 15, 0.1, 2048*1000)
	withResources(t, none, "head", 10, 15, 0.1, 2048*1000)
	if report, _ := render(t, options{baseName: "main", loadDir: none}); strings.Contains(report, "Request validation") {
		t.Error("a report without validation calls has the section")
	}
}

// TestRecordValidator checks main's record keeps the validation calls, and
// the trends page charts them.
func TestRecordValidator(t *testing.T) {
	dir := headDir(t)
	withValidator(t, dir, "head")
	var out strings.Builder
	err := runRecord([]string{"-sha", "abc1234", "-subject", "s", "-time", "2026-10-06T10:00:00Z",
		"-bench", benchOutput(t, "cmd/api", 6, map[string][3]float64{"API/GET": {40000, 17000, 138}}), "-load", dir}, &out)
	if err != nil {
		t.Fatal(err)
	}
	var r record
	if err := json.Unmarshal([]byte(out.String()), &r); err != nil {
		t.Fatal(err)
	}
	l := r.Load
	if l == nil || deref(l.ValidatorMedianMS) != 2.5 || deref(l.ValidatorP99MS) != 5.0 || deref(l.ValidatorCallsPerRequest) != 0.1 {
		t.Fatalf("validator in the record = %v, %v, %v; want 2.5ms, 5ms, 0.1 a request", deref(l.ValidatorMedianMS), deref(l.ValidatorP99MS), deref(l.ValidatorCallsPerRequest))
	}
	var page strings.Builder
	if err := runTrends([]string{"-records", writeRecords(t, r)}, &page); err != nil {
		t.Fatal(err)
	}
	mustContain(t, page.String(), "Request validation call", "abc1234 p99: 5.00 ms")
}
